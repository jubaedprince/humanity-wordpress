<?php
/**
 * BuddyPress Members Classes.
 *
 * @package BuddyPress
 * @subpackage MembersClasses
 */

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

require dirname( __FILE__ ) . '/classes/class-bp-signup.php';
