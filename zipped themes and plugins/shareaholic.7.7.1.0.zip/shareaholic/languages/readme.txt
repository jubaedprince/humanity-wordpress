== Shareaholic in Your Language ==

Shareaholic is used all over the world. Our goal is to support Shareaholic in the native language of all our users and people who want to use our products.

== Shareaholic for WordPress is currently localized in the following languages: ==

* English (en)
* Simplified Chinese (zh_CN) by [Larry Zhang](http://zhxl.me)
* Greek (el_EL) by [Takis Bouyouris](http://www.nevma.gr)
* Greek (el_GR) by [Takis Bouyouris](http://www.nevma.gr)
* German (de_DE) by Oliver Heinrich
* French (fr_FR) by Rozenn Dagorn
* Dutch (nl_NL) by Patrick Ruers
* Português (pt_PT)
* Afrikaans (af_AF)
* Italian (it_IT)
* Turkish (tr_TR) by [Plantekno Bitki](http://plantekno.com)
* Spanish - Mexico (es_MX) by [Luis Jared Pardo](http://www.clickseguro.net)
* Spanish - Spain (es_ES) by [David Marco Busto](http://alfabetadigital.com)
* Romanian (ro_RO)
* Contribute a translation!

== How to translate Shareaholic into your own language ==

We would appreciate your help in translating Shareaholic into even more languages! It doesn’t take much to get started. Thanks so much! Instructions: https://shareaholic.com/tools/wordpress/translate

== Notes ==

* http://codex.wordpress.org/WordPress_in_Your_Language