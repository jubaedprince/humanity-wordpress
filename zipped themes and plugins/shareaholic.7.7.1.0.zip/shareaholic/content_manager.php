<?php
/**
 * File for the ShareaholicContentManager class.
 *
 * @package shareaholic
 */

/**
 * An interface to the Shareaholic Content Manager API's
 *
 * @package shareaholic
 */
class ShareaholicContentManager {

 }
 
?>